# api-slimv4
Template inicial de una API Rest utilizando Slim Framework V4 
